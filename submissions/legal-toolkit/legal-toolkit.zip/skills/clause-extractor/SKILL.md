---
name: clause-extractor
description: Use this skill whenever the user asks to extract specific clauses (e.g. liability, termination, IP) from a contract into a structured table.
---

# Clause Extractor

Pull named clauses out of a contract into a clean, structured table.

## Workflow
1. Ask which clause types to extract (default: liability, termination, IP).
2. Locate each clause in the document.
3. Return a table with clause name, section reference, and verbatim text.
