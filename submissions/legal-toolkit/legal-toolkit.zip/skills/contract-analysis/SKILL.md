---
name: contract-analysis
description: Use this skill whenever the user asks to review a contract, find risky clauses, or summarize an agreement's key terms.
---

# Contract Analysis

Systematically review a contract and surface commercial terms, risks, and obligations.

## Workflow
1. Read the uploaded contract.
2. Extract and categorize each clause.
3. Flag risk areas with a severity rating.
4. Produce a structured summary with recommendations.

See `references/clause-taxonomy.md` for the clause categories.
