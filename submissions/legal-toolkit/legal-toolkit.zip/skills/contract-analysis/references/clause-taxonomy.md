# Clause taxonomy

- Commercial: pricing, payment, renewal, term.
- Risk: indemnification, limitation of liability, IP assignment.
- Operational: SLAs, support, data handling.
