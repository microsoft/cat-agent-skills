"""Outline a SQL query's clauses for the Query Explainer skill."""
import re
import sys

CLAUSES = ["SELECT", "FROM", "JOIN", "WHERE", "GROUP BY", "HAVING", "ORDER BY", "LIMIT"]


def outline(sql: str) -> None:
    for clause in CLAUSES:
        m = re.search(rf"\b{clause}\b", sql, re.IGNORECASE)
        if m:
            print(f"- {clause}")


if __name__ == "__main__":
    outline(sys.stdin.read())
