# Query Explainer bundle
`explain.py` reads a SQL query from stdin and prints a clause outline.
