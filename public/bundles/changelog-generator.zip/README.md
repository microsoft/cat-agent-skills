# Changelog Generator bundle

`group_commits.py` reads commit lines from stdin and prints them grouped by
changelog section.

```bash
git log --pretty=%s v1.0.0..HEAD | python group_commits.py
```
