"""Group conventional-commit messages by type for the Changelog Generator skill."""
import sys
from collections import defaultdict

BUCKETS = {"feat": "Added", "fix": "Fixed", "refactor": "Changed", "remove": "Removed"}


def group(lines):
    out = defaultdict(list)
    for line in lines:
        line = line.strip()
        if not line:
            continue
        prefix = line.split(":", 1)[0].split("(", 1)[0].strip().lower()
        out[BUCKETS.get(prefix, "Changed")].append(line)
    return out


if __name__ == "__main__":
    for section, items in group(sys.stdin).items():
        print(f"### {section}")
        for item in items:
            print(f"- {item}")
        print()
